# 来源目录

共23项，核查日期2026-10-31；旧版已读来源沿用，新增配置和开发资料本轮核对。只作摘要与链接，不转载完整产品手册。

## S01 OpenAI Codex App Server

官方技术文档。提供会话和轮次事件、审批请求与客户端响应机制。可研究受支持客户端桥接，不能据此声称已控制当前桌面应用。

[OpenAI Codex App Server](https://learn.chatgpt.com/docs/app-server)

## S02 HachimoDock

作者仓库与README。桌面管理器与ESP32-P4设备协作，展示编码会话状态与语音交互。只借鉴状态交接思路。

[HachimoDock](https://github.com/YizhengWw/HachimoDock)

## S03 HachimoDock项目许可证

作者许可证。自定义非商业源码可见许可；独立产品开发等用途需要另行许可，不应标为标准开源或直接移植。

[HachimoDock项目许可证](https://github.com/YizhengWw/HachimoDock/blob/main/LICENSE)

## S04 VibeKeys应用与配置

作者仓库与README。实体键映射语音、接受、退出等操作；简单按键宏不理解具体权限范围。GPL-3.0，采用前审查义务。

[VibeKeys应用与配置](https://github.com/second-state/vibekeys_app)

## S05 VibeKeys固件

作者仓库与README。硬件固件可供分工与消息传输参考；本次仓库元数据未识别许可证，不能默认可复制。

[VibeKeys固件](https://github.com/second-state/vibekeys_firmware)

## S06 VibeBoard

作者仓库与README。将编码状态映射到实体按键、灯光与交互。并非所有同类键盘都是三键，本次未确认其许可证。

[VibeBoard](https://github.com/zuichen123/VibeBoard)

## S07 Deepgram Vibe Coder

作者仓库与README。语音编码与编辑器操作参考；依赖其服务和编辑器集成，不是灵机一动即装即用插件。MIT。

[Deepgram Vibe Coder](https://github.com/deepgram/vibe_coder)

## S08 PosturePal

作者仓库与README。摄像头姿态监测、个人校准与提醒参考，MIT。桌面软件环境与本项目主控不同，不把项目阈值当医学结论。

[PosturePal](https://github.com/shensquared/PosturePal)

## S09 UPRIGHT个人校准说明

品牌使用说明。可借鉴用户自己的舒适基准和重新校准流程。该产品是佩戴式方案，不等同摄像头模型。

[UPRIGHT个人校准说明](https://www.uprightpose.com/blog/calibration/)

## S10 EKO倩影系列感应环境桶

品牌产品说明。参考感应与手动模式、缓闭等交互。感应器靠近触发不等于视觉识别投放意图。

[EKO倩影系列感应环境桶](https://www.eko.com.cn/products/sensor-bins/倩影系列感应环境桶/)

## S11 Smart-Bin

作者仓库与README。Arduino、超声测距和舵机的垃圾桶示例，MIT。可参考开关状态，不能证明视觉理解或防夹。

[Smart-Bin](https://github.com/2black0/Smart-Bin)

## S12 Mori Quiet Lamp支持页

品牌支持说明。参考安静模式、柔和灯光和明确的用户控制入口。避免照搬造型或品牌。

[Mori Quiet Lamp支持页](https://www.onekindartifact.com/eu/support/categories/dd8adb14-8c2c-4154-91d6-152d22e6c9dc)

## S13 LivingAI EMO

品牌产品说明。参考桌面伙伴的语音、动作与状态表达。产品宣传不证明小桶具有同等识别或运动能力。

[LivingAI EMO](https://living.ai/emo/)

## S14 小智ESP32

作者仓库与README。参考唤醒、语音链路及工具控制分工，MIT。其当前SDK和板型要求需另核，不能替换比赛要求的平台与主板。

[小智ESP32](https://github.com/78/xiaozhi-esp32)

## S15 Ulanzi Vibe Key软件说明

品牌配置文档。明确采用语音、确认、拒绝三个核心按键加旋钮；语音通过配置第三方快捷键实现。小桶可参考三个明确入口，而不照搬其权限含义。

[Ulanzi Vibe Key软件说明](https://docs.ulanzistudio.com/vibekey/en/software/)

## S16 VibeKeys远程语音配置

项目配置文档。按住或切换录音、识别后校对、确认提交或取消。语音识别需要另外配置服务，实体按键本身不等于智能理解。

[VibeKeys远程语音配置](https://vibekeys.dev/docs/voice-input/)

## S17 Ulanzi Codex与Claude状态同步

品牌技术说明。通过配套软件尝试安装Hooks取得状态；灯光聚焦单一会话，不用叠加节奏表示待批数量。仅为厂商方案说明，未在小桶验证。

[Ulanzi Codex与Claude状态同步](https://docs.ulanzistudio.com/vibekey/faq/codex-claude-status.html)

## S18 Ulanzi AU05-X WorkBuddy联名款配置

品牌配置说明。三个核心键与旋钮支持语音、发送或确认、取消等交互，并有多种工作流预设。具体快捷键受系统、预设和目标软件影响。

[Ulanzi AU05-X WorkBuddy联名款配置](https://docs.ulanzistudio.com/vibekey/au05-x/)

## S19 Vite排错文档

官方开发文档。作为开发环境与构建问题的查证入口；先收集版本、启动方式和完整错误，不把不同错误混为单一原因。

[Vite排错文档](https://vite.dev/guide/troubleshooting.html)

## S20 MDN跨源资源共享

Web技术文档。跨源访问由浏览器及服务端响应规则共同约束，排查时核对请求与响应；不建议把关闭浏览器安全机制作为通用解法。

[MDN跨源资源共享](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CORS)

## S21 Vite环境变量与模式

官方开发文档。客户端暴露的环境变量可能进入构建产物，不把后端私密凭据放入公开前端变量；开发与生产配置需分别核对。

[Vite环境变量与模式](https://vite.dev/guide/env-and-mode.html)

## S22 Vite静态部署

官方开发文档。区分本地预览、构建产物和真实部署；本地preview不应被当作生产服务。小桶不把网页可访问等同业务正确。

[Vite静态部署](https://vite.dev/guide/static-deploy.html)

## S23 GitHub合并冲突

官方开发文档。冲突需要确定最终应保留的内容；不能仅凭“选最新”覆盖队友修改。示例用于澄清和交接，不自动实施合并。

[GitHub合并冲突](https://docs.github.com/en/pull-requests/reference/merge-conflicts)
