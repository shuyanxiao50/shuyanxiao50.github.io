# 工程结构

```
apps/main/
├── main.c                    应用入口、任务装配与启动顺序
├── agent/agent_app.c         平台 Agent 会话、音频通道与资源模式
├── cloud/ljyd_cloud.c        灵机一动连云、配网与设备指令
├── peripheral/
│   ├── bsp_camera.c          SPI 摄像头取帧
│   ├── pose_stream.c         端侧姿态推理、骨架叠加与 MJPEG 流
│   ├── bsp_ws2812.c          RGB 灯环
│   ├── bsp_servo.c           嘴盖舵机
│   ├── dsh_voice.c           云端语音 / 本地口述模式切换
│   ├── companion_voice.c     本地唤醒与单轮采集租约
│   └── cue_server.c          DSH 事件 → 振动 / 提示音 / 舵机
└── lj_components/            番茄钟、闹钟、播放等平台组件
```
